import './App.css';
import styles from './Nav.module.css';
import { useState } from 'react';

function Header(props) {
  const [title, setTitle] = useState(props.title);
  const [content, setContent] = useState(props.content);
  console.log('Header');
  
  function update() {
    setContent( content + '!' );
  }

  return (
    <header>
      <h1 onClick={update}>{title}</h1>
      {content}
    </header>
  );
}

// props 데이터를 state 데이터로 수정
const Nav = (props) => {
  const [subjects, setSubjects] = useState(props.list);
  console.log('Nav');
  const [isUpdate, setIsUpdate] = useState(false);
  const [updateIndex, setUpdateIndex] = useState(-1);
  const [updateContent, setUpdateContent] = useState('');

  const showUpdate = (index) => {
    setIsUpdate(true);
    setUpdateIndex(index);
    setUpdateContent(subjects[index]);
  }
  const update = () => {
    const value = document.querySelector('#content').value;
    const updateList = [... subjects];
    updateList[updateIndex] = value;
    setSubjects(updateList);
    setIsUpdate(false);
  }
  const onChange = (e) => {
    const content = e.target.value;
    setUpdateContent(content);
  }

  const append = () => {
    const data = parseInt(Math.random() * 10) + 1;
    const updateList = [...subjects];
    updateList.push(data);
    setSubjects(updateList);
  }
  function remove(index) {
    const updateList = [...subjects];
    updateList.splice(index, 1);
    setSubjects(updateList);
  }

  return (
    <nav>
      <button onClick={append}>추가2</button>
      <ul className={styles.border}>
        {
          subjects.map((v, i) => {
            return <li key={i}>
                     <a href={`${i+1}.html`}>{v}</a>
                     <button onClick={() => showUpdate(i)}>수정</button>
                     <button onClick={() => remove(i)}>삭제</button>
                   </li>;
          })
        }
      </ul>
      
      {
        isUpdate ? (
          <div>
            수정모드: {updateIndex}번
            <input type='text' id='content' value={updateContent}
                    onChange={onChange}/>
            <button onClick={update}>완료</button>
          </div>
        ) : null
      }
    </nav>
  );
}

function App() {
  const [list, setList] = useState(['HTML', 'CSS2', 'JavaScript']);
  console.log(list);
  // const append = () => {
  //   const data = parseInt(Math.random() * 10) + 1;
  //   const updateList = [...list];
  //   updateList.push(data);
  //   setList(updateList);
  // }
  return (
    <div className="App">
      <Header title='AAA' content='BBB'></Header>
      {/* <button onClick={append}>추가1</button> */}
      <Nav list={list}></Nav>
    </div>
  );
}

export default App;
